package com.jsp.model;

/**
 * Product.java
 * This is a model class represents a Product entity
 *
 *
 */
public class Product {
	protected int id;
	protected String name;
	protected String pack;
	protected String max;
	protected String purchase;
	protected String sell;
	protected String tax;
	
	
	public Product() {
	}
	
	
	public Product(String name, String pack, String max, String purchase, String sell, String tax) {
		super();
		this.name = name;
		this.pack = pack;
		this.max = max;
		this.purchase = purchase;
		this.sell = sell;
		this.tax = tax;
		
	}

	public Product(int id, String name, String pack, String max, String purchase, String sell, String tax) {
		super();
		this.id = id;
		this.name = name;
		this.pack = pack;
		this.max = max;
		this.purchase = purchase;
		this.sell = sell;
		this.tax = tax;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPack() {
		return pack;
	}
	public void setPack(String pack) {
		this.pack = pack;
	}
	public String getMax() {
		return max;
	}
	public void setMax(String max) {
		this.max = max;
	}
	public String getPurchase() {
		return purchase;
	}
	public void setPurchase(String purchase) {
		this.purchase = purchase;
	}
	public String getSell() {
		return sell;
	}
	public void setSell(String sell) {
		this.sell= sell;
	}
	public String getTax() {
		return tax;
	}
	public void setTax(String tax) {
		this.tax = tax;
	}
}
